package roomschedulerlianghkl5249;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import roomschedulerlianghkl5249.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.sql.Timestamp;
import java.util.Calendar;
/**
 *
 * @author Hanwen 
 */
public class waitlistQueries {
    private static Connection connection;
    private static ArrayList<String> waitlist_name = new ArrayList<String>();
    private static ArrayList<String> waitlist_date = new ArrayList<String>();
    private static ArrayList<String> waitlist_seats = new ArrayList<String>();
    public static String waitlist_textarea;
    private static ResultSet resultSet;
    private static PreparedStatement getDateList;
    private static PreparedStatement emptyTable;
    private static PreparedStatement dropWaitlist;
    
    public static void getWaitlistName(){
        connection = DBConnection.getconnection();
        waitlist_name = new ArrayList<String>();

            try
            {
                getDateList = connection.prepareStatement("SELECT FACULTY FROM WAITLIST ORDER BY FACULTY");
                resultSet = getDateList.executeQuery();

                while(resultSet.next())
                {
                    waitlist_name.add(resultSet.getString(1));
                }
            }
            catch(SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
    }
    
    public static void getWaitlistDate(){
        connection = DBConnection.getconnection();
        waitlist_date = new ArrayList<String>();

            try
            {
                getDateList = connection.prepareStatement("SELECT DATE FROM WAITLIST ORDER BY FACULTY");
                resultSet = getDateList.executeQuery();

                while(resultSet.next())
                {
                    waitlist_date.add(resultSet.getString(1));
                }
            }
            catch(SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
    }
    
    public static void getWaitlistSeats(){
        connection = DBConnection.getconnection();
        waitlist_seats = new ArrayList<String>();

            try
            {
                getDateList = connection.prepareStatement("SELECT SEATS FROM WAITLIST ORDER BY FACULTY");
                resultSet = getDateList.executeQuery();

                while(resultSet.next())
                {
                    waitlist_seats.add(resultSet.getString(1));
                }
            }
            catch(SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
    }
    
    public static void resetWaitlist(){
        connection = DBConnection.getconnection();
        getWaitlistName();
        getWaitlistDate();
        getWaitlistSeats();
        
        try{
            emptyTable = connection.prepareStatement("DELETE FROM WAITLIST");
            emptyTable.executeUpdate();
            for(int i =0; i < waitlist_date.size (); i++) {
                reservationQueries.addReservation(waitlist_date.get(i),waitlist_name.get(i),waitlist_seats.get(i));
            }
        }        
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }        
        
    }
    
    public static void DisplayWaitlist(){
        waitlist_textarea = "";
        getWaitlistName();
        getWaitlistDate();
        getWaitlistSeats();
        for(int i =0; i < waitlist_name.size (); i++){
            String name = waitlist_name.get(i);
            String date = waitlist_date.get(i);
            String seats = waitlist_seats.get(i);
            if(i == 0){
                waitlist_textarea = String.format("%s %s %s\n",name,date,seats);
            }
            else{
                waitlist_textarea = waitlist_textarea+String.format("%s %s %s\n",name,date,seats);
            }
        }
    }
    
    public static void dropWaitlist(String name, String date){
        connection = DBConnection.getconnection();
        try{
            dropWaitlist=connection.prepareStatement("DELETE FROM WAITLIST WHERE FACULTY=(?) AND DATE=(?)");
            dropWaitlist.setString(1,name);
            dropWaitlist.setString(2,date);
            dropWaitlist.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
    }
}
