package roomschedulerlianghkl5249;


import roomschedulerlianghkl5249.DBConnection;
import java.sql.*;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hanwen
 */

public class Date {
    private Date date;
    private static Connection connection;
    private static PreparedStatement getDateList;
    private static PreparedStatement addDate;
    private static ArrayList<String> dates = new ArrayList<String>();
    public static ResultSet result;
    
    public Date (Date date){
        setDate(date);
    }
    
    public void setDate (Date date) {
        this.date=date;
    }
    
    public Date getDate(){
        return date;
    }
    
    public static ArrayList<String> getAllDates(){
        connection = DBConnection.getconnection();
        ArrayList<String> dates = new ArrayList<String>();        
        try
        {
            getDateList = connection.prepareStatement("SELECT DATE FROM DATE ORDER BY DATE");
            result = getDateList.executeQuery();
            while(result.next()){
                dates.add(result.getString(1));
                
            }
        }
        catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return dates;
    }
    
     public static void addDate(String date){
        connection = DBConnection.getconnection();
        try
        {
            addDate = connection.prepareStatement("INSERT INTO DATE (DATE) VALUES (?)");
            addDate.setString(1,date);
            addDate.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
    }
}
