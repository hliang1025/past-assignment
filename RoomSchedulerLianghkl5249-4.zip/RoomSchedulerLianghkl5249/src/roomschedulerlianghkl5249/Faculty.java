package roomschedulerlianghkl5249;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import roomschedulerlianghkl5249.DBConnection;
import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author Hanwen
 */
public class Faculty {
    private String name;
    //public static String reservation_text;
    //public static String waitlist_text;
    private static ArrayList<String> faculty = new ArrayList<String>();
    private static PreparedStatement addFaculty;
    private static PreparedStatement getFaculty;
    private static PreparedStatement reservation;
    private static PreparedStatement waitlist;
    private static Connection connection;
    public static ResultSet result;
    public static ResultSet result2;
    
    public Faculty(String name){
        setName(name);
    }
    
    public void setName(String name) {
        this.name=name;
    }
    
    public String getName(){
        return name;
    }
    
    public static void addFaculty(String name){
        connection = DBConnection.getconnection();
        try
        {
            addFaculty = connection.prepareStatement("INSERT INTO FACULTY (FACULTY) VALUES (?)");
            addFaculty.setString(1,name);
            addFaculty.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
    }
    
    public static ArrayList<String> getFaculty()
    {
        connection = DBConnection.getconnection();
        ArrayList<String> faculty = new ArrayList<String>();
        try
        {
            getFaculty=connection.prepareStatement("SELECT FACULTY FROM FACULTY ORDER BY FACULTY");
            result=getFaculty.executeQuery();
            
            while (result.next()){
                faculty.add(result.getString(1));
            }
            
        } 
        catch (SQLException ex) {
            ex.printStackTrace();
        }
        return faculty;
    }
    
    public static String facultyReservation(String name){
        connection = DBConnection.getconnection();
        String reservation_text="";
        try
        {            
            reservation=connection.prepareStatement("SELECT * FROM RESERVATIONS WHERE FACULTY=(?)");
            reservation.setString(1,name);
            result=reservation.executeQuery();
            while(result.next()){
                for (int i=1;i<=3;i++){
                    String value = result.getString(i);
                    reservation_text=reservation_text+value+" ";
                }
                reservation_text+="\n";                
            }
        }
         catch (SQLException ex) {
            ex.printStackTrace();
        }
        return reservation_text;
    }
    
    public static String facultyWaitlist(String name){
        connection = DBConnection.getconnection();
        String waitlist_text="";
        try
        { 
            waitlist=connection.prepareStatement("SELECT * FROM WAITLIST WHERE FACULTY=(?)");
            waitlist.setString(1,name);
            result2=waitlist.executeQuery();
            while(result2.next()){
                for (int i=1;i<=2;i++){
                    String value = result2.getString(i);
                    waitlist_text=waitlist_text+value+" ";
                }
                waitlist_text+="\n";                
            }
        }
         catch (SQLException ex) {
            ex.printStackTrace();
        }
        return waitlist_text;
    }
}
