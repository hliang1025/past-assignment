package roomschedulerlianghkl5249;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import roomschedulerlianghkl5249.DBConnection;
import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author Hanwen
 */

public class roomQueries {
    private static PreparedStatement SelectAllRoom;
    private static PreparedStatement addRoom;
    private static PreparedStatement dropRoom;
    private static Connection connection;
    private static ArrayList<String> room = new ArrayList<String>();
    private static ArrayList<String> seats = new ArrayList<String>();
    public static ResultSet result;
    
    
    public roomQueries()
    {
        try
        {
            connection = DBConnection.getconnection();
            SelectAllRoom = connection.prepareStatement("SELECT * FROM ROOMS ORDER BY SEATS");
            
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
    }
    
    public static ArrayList<String> getAllRooms(){
        
        connection = DBConnection.getconnection();
        ArrayList<String> room = new ArrayList<String>();
        
        try
        {
            SelectAllRoom = connection.prepareStatement("SELECT NAME FROM ROOMS");
            result=SelectAllRoom.executeQuery();
            while(result.next()){
                room.add(result.getString(1));
                
            }
        }
        catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return room;
    }
    
    public static ArrayList<String> getAllSeats(){
        connection = DBConnection.getconnection();
        ArrayList<String> seats = new ArrayList<String>();
        
        try
        {
            SelectAllRoom = connection.prepareStatement("SELECT * FROM ROOMS ORDER BY SEATS");
            result=SelectAllRoom.executeQuery();
            while(result.next()){
                seats.add(result.getString(2));
                
            }
        }
        catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return seats;
    }
    
    public static void addRoom(String name,int seats){
        connection = DBConnection.getconnection();
        try
        {
            addRoom = connection.prepareStatement("INSERT INTO ROOMS (NAME,SEATS) VALUES (?,?)");
            addRoom.setString(1,name);
            addRoom.setInt(2,seats);
            addRoom.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        } 
    }
    
    public static void dropRoom(String name){
        connection = DBConnection.getconnection();
        try
        {
            dropRoom = connection.prepareStatement("DELETE FROM ROOMS WHERE NAME=(?)");
            dropRoom.setString(1,name);
            dropRoom.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
    }
}
