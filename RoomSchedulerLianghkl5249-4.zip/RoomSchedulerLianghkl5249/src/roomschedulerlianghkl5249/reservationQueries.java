package roomschedulerlianghkl5249;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import roomschedulerlianghkl5249.DBConnection;
import java.sql.*;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.ArrayList;
/**
 *
 * @author Hanwen
 */


public class reservationQueries {
    private static Connection connection;
    private static ArrayList<String> Date = new ArrayList<String>();
    static ArrayList<String> reservation_room = new ArrayList<String>();
    static ArrayList<String> reservation_date = new ArrayList<String>();
    static ArrayList<String> reservation_name = new ArrayList<String>();
    static ArrayList<String> reservation_seats = new ArrayList<String>();
    private static boolean add_or_not;
    public static String reservation_textarea;
    private static ArrayList<ArrayList> reservation_status = new ArrayList<>();
    private static ArrayList<String> reservation = new ArrayList<String>();
    private static PreparedStatement addReservation;
    private static PreparedStatement getDateList;
    private static PreparedStatement emptyTable;
    private static PreparedStatement dropReservation;
    private static ResultSet resultSet;
    private static String select_room;
    public static String statuslabel;
    
    public static void addReservation(String date, String name, String seats){
        connection = DBConnection.getconnection();
        add_or_not = true;
        getReservationRoom();
        getReservationDate();
        getReservationName();
        ArrayList<String> room_list = new ArrayList<String>();
        ArrayList<String> seats_number = new ArrayList<String>();
        seats_number = roomQueries.getAllSeats();
        room_list = roomQueries.getAllRooms();
        getReservation_status();
        int index = 0;
        int int_seats = Integer.parseInt(seats);
        for(String seat:seats_number){
            int int_seat = Integer.parseInt(seat);
            if(int_seats<=int_seat){
                select_room = room_list.get(index);
                ArrayList<String> reserve = new ArrayList<>();
                reserve.add(name);
                reserve.add(select_room);
                reserve.add(date);
                for(ArrayList try_reserve:reservation_status){
                    if(reserve.get(0).equals(try_reserve.get(0))){
                        if(reserve.get(2).equals(try_reserve.get(2))){
                            add_or_not = false;
                            break;                        
                        }
                    }
                    if(reserve.get(1).equals(try_reserve.get(1))){
                        if(reserve.get(2).equals(try_reserve.get(2))){
                            index+=1;
                            break;
                        }
                    }
                }
                if(add_or_not == false)break;
            }
            else{
                index+=1;
                continue;
            }
            if(index+1 > room_list.size()){
                add_or_not = false;
                break;
            }
        }

        Timestamp currentTimestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
        if(add_or_not == true){  
            select_room = room_list.get(index);
            statuslabel = String.format("successfully add faculty:%s Room:%s Date:%s Seats:%s",name,select_room,date,seats);
            try
                {
                    addReservation = connection.prepareStatement("INSERT INTO RESERVATIONS (Faculty, Room, Date, Seats, Timestamp) VALUES(?, ?, ?, ?, ?)");
                    addReservation.setString(1,name);
                    addReservation.setString(3, date);
                    addReservation.setString(2,select_room);
                    addReservation.setString(4,seats);
                    addReservation.setTimestamp(5, currentTimestamp);
                    addReservation.executeUpdate();
                }

            catch(SQLException sqlException)
                {
                    sqlException.printStackTrace();
                }
        }
        else{
            statuslabel = String.format("successfully add into waitlist faculty:%s Date:%s Seats:%s",name,date,seats);
            try
                {
                    addReservation = connection.prepareStatement("INSERT INTO WAITLIST (Faculty,Date, Seats, Timestamp) VALUES(?, ?, ?, ?)");
                    addReservation.setString(1,name);
                    addReservation.setString(2, date);
                    addReservation.setString(3,seats);
                    addReservation.setTimestamp(4, currentTimestamp);
                    addReservation.executeUpdate();
                }

            catch(SQLException sqlException)
                {
                    sqlException.printStackTrace();
                }
        }

    }
    
    public static void getReservationRoom(){
        connection = DBConnection.getconnection();
            reservation_room = new ArrayList<String>();

            try
            {
                getDateList = connection.prepareStatement("SELECT ROOM FROM RESERVATIONS ORDER BY FACULTY");
                resultSet = getDateList.executeQuery();

                while(resultSet.next())
                {
                    reservation_room.add(resultSet.getString(1));
                }
            }
            catch(SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
    }
    
    public static void getReservationName(){
        connection = DBConnection.getconnection();
        reservation_name = new ArrayList<String>();

            try
            {
                getDateList = connection.prepareStatement("SELECT FACULTY FROM RESERVATIONS ORDER BY FACULTY");
                resultSet = getDateList.executeQuery();

                while(resultSet.next())
                {
                    reservation_name.add(resultSet.getString(1));
                }
            }
            catch(SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
    }
    
    public static void getReservationDate(){
        connection = DBConnection.getconnection();
        reservation_date = new ArrayList<String>();

            try
            {
                getDateList = connection.prepareStatement("SELECT DATE FROM RESERVATIONS ORDER BY FACULTY");
                resultSet = getDateList.executeQuery();

                while(resultSet.next())
                {
                    reservation_date.add(resultSet.getString(1));
                }
            }
            catch(SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
    }
    
     public static void getReservationSeats(){
        connection = DBConnection.getconnection();
        reservation_seats = new ArrayList<String>();

            try
            {
                getDateList = connection.prepareStatement("SELECT SEATS FROM RESERVATIONS ORDER BY FACULTY");
                resultSet = getDateList.executeQuery();

                while(resultSet.next())
                {
                    reservation_seats.add(resultSet.getString(1));
                }
            }
            catch(SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
    }
    
    // this resets the reservation when a room is dropped 
    public static void resetReservation(){
        connection = DBConnection.getconnection();
        getReservationName();
        getReservationDate();
        getReservationSeats();
        try{
            emptyTable = connection.prepareStatement("DELETE FROM RESERVATIONS");
            emptyTable.executeUpdate();
            for(int i =0; i < reservation_name.size (); i++) {
                reservationQueries.addReservation(reservation_date.get(i),reservation_name.get(i),reservation_seats.get(i));
            }
        }
        
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
    }
   
    public static void getReservation_status(){
        for(int i =0; i < reservation_date.size (); i++){
            ArrayList<String> status = new ArrayList<>();
            status.add(reservation_name.get(i));
            status.add(reservation_room.get(i));
            status.add(reservation_date.get(i));
            reservation_status.add(status);
        }
    }
    
    public static void DisplayReservation(String Date){
        GetAllReservations();
        reservation_textarea = "";
        for (int i =0; i<reservation.size();i++){
            String display = reservation.get(i);
            if (i==0) {
                reservation_textarea=display;
            }
            else{
                reservation_textarea=reservation_textarea+"\n"+display;
            }
        }        
        
        
    }
    
    public static ArrayList<String> GetAllReservations(){
        getReservationRoom();
        getReservationDate();
        getReservationName();
        reservation = new ArrayList<String>();
        for(int i =0; i < reservation_date.size (); i++){
            String name = reservation_name.get(i);
            String room = reservation_room.get(i);
            String date = reservation_date.get(i);
            
            String add_on = name+" reserved "+room+" on "+date;
            reservation.add(add_on);
            
        }
        return reservation;
    }
    
    public static void dropReservation(String name, String date){
        connection = DBConnection.getconnection();
        try{
            dropReservation=connection.prepareStatement("DELETE FROM RESERVATIONS WHERE FACULTY=(?) AND DATE=(?)");
            dropReservation.setString(1,name);
            dropReservation.setString(2,date);
            dropReservation.executeUpdate();
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
    }
}
