package roomschedulerlianghkl5249;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hanwen
 */
public class Rooms {
    private String name;
    private int seats;
    
    public Rooms (String name,int seats){
        setName(name);
        setSeats(seats);
    }
    
    public void setName(String name){
        this.name=name;
    }
    
    public String getName(){
        return name;
    }
    
    public void setSeats(int seats){
        this.seats=seats;
    }
    
    public int getSeat() {
        return seats;
    }
}
